window.onload = function() {
    showTab('acasa');  // Să se afișeze tab-ul "Acasă" la început
};

function showTab(tabId) {
    const tabs = document.querySelectorAll('.tab'); // Selectăm tab-urile
    const slider = document.querySelector('.slider-container'); // Selectăm slider-ul
    const textProduse = document.querySelector('.textproduse'); // Selectăm secțiunea textproduse
    const galerieProduse = document.querySelector('.galerie-info'); // Selectăm galeria de produse
    const carousel = document.querySelector('.carousel-container'); // Selectăm caruselul pentru Istoric

    tabs.forEach(tab => {
        tab.classList.remove('active'); // Ascunde toate tab-urile
    });

    // Ascundem slider-ul, textul și galeria în afară de tab-ul Produse
    if (tabId === 'produse') {
        slider.style.display = 'block'; // Afișăm slider-ul doar în Produse
        textProduse.style.display = 'block'; // Afișăm textul despre produse
        galerieProduse.style.display = 'block'; // Afișăm galeria de produse
        carousel.style.display = 'none'; // Ascundem caruselul în afacere de Istoric
    } else {
        slider.style.display = 'none'; // Ascundem slider-ul în afacere de Produse
        textProduse.style.display = 'none'; // Ascundem textul despre produse
        galerieProduse.style.display = 'none'; // Ascundem galeria de produse
    }

    if (tabId === 'istoric') {
        carousel.style.display = 'block'; // Afișăm caruselul doar în Istoric
    } else {
        carousel.style.display = 'none'; // Ascundem caruselul în afacere de Istoric
    }

    // Afișăm tab-ul selectat
    document.getElementById(tabId).classList.add('active');
}
  

function activateSlider() {
    const slider = document.querySelector('.slider-container');c
    if (!slider) return;
    slider.scrollLeft = 0;

    let intervalId = setInterval(() => {
        slider.scrollLeft += 250; // Derulează cu lățimea unei imagini
        if (slider.scrollLeft >= slider.scrollWidth - slider.clientWidth) {
            slider.scrollLeft = 0; // Revine la început când ajunge la final
        }
    }, 3000);

    // Oprește intervalul când tab-ul nu mai este activ
    document.getElementById('produse').addEventListener('transitionend', () => {
        clearInterval(intervalId);
    });
}

const carousel = document.querySelector('.carousel');
const carouselSlides = document.querySelectorAll('.carousel-slide');
const prevButton1 = document.querySelector('.prev-button1');
const nextButton1 = document.querySelector('.next-button1');
const progressBar = document.querySelector('.progress-bar1::after');
let currentIndex = 0;
const slideInterval = 3000; // 3 secunde

function updateCarousel() {
  carousel.style.transform = `translateX(-${currentIndex * 100}%)`;
  resetProgressBar();
}
function resetProgressBar() {
  const bar = document.querySelector('.progress-bar1::after');
  bar.style.transition = "none";
  bar.style.width = "0";

  setTimeout(() => {
    bar.style.transition = `width ${slideInterval}ms linear`;
    bar.style.width = "100%";
  }, 50);
}
function nextSlide() {
  currentIndex = (currentIndex < carouselSlides.length - 1) ? currentIndex + 1 : 0;
  updateCarousel();
}
function startAutoSlide() {
  setInterval(() => {
    nextSlide();
  }, slideInterval);
}
prevButton1.addEventListener('click', () => {
  currentIndex = (currentIndex > 0) ? currentIndex - 1 : carouselSlides.length - 1;
  updateCarousel();
});

nextButton1.addEventListener('click', () => {
  currentIndex = (currentIndex < carouselSlides.length - 1) ? currentIndex + 1 : 0;
  updateCarousel();
});
updateCarousel();
startAutoSlide();


